%%
% * Author:  Eng. Salah Abbas Taha (S.A.Taha)(salahabbas041@gmail,com,07748191514,Tele.@Eng_441)
% * Date: 06.11.2024
function D = GWO(Vpv, Ipv, Enabled)
    Dinit = 0.5;
    SearchAgents_no = 6;   % Number of search agents
    Max_iteration = 10;    % Maximum number of iterations
    lb = 0.3;              % Lower bound
    ub = 0.9;              % Upper bound
    a = 2;                 % Control parameter
    power_delta = 0.01;

    persistent params;

    if isempty(params)
        params = initialize(SearchAgents_no, lb, ub);
    end

    fitness = Vpv * Ipv;

    if params.running == false
        if abs(fitness - params.power_last) / params.power_last >= power_delta
            params = initialize(SearchAgents_no, lb, ub);
        else
            D = params.Alpha_pos;
            params.power_last = fitness;
            return;
        end
    end

    params.power_last = fitness;
    params.fitness(params.index) = fitness;

    D = params.Positions(params.index);

    params.index = params.index + 1;

    if params.index > SearchAgents_no
        params.index = 1;
        params.iter = params.iter + 1;

        [sorted_fitness, sorted_idx] = sort(params.fitness, 'descend');
        params.Alpha_pos = params.Positions(sorted_idx(1));
        params.Alpha_score = sorted_fitness(1);
        params.Beta_pos = params.Positions(sorted_idx(2));
        params.Beta_score = sorted_fitness(2);
        params.Delta_pos = params.Positions(sorted_idx(3));
        params.Delta_score = sorted_fitness(3);

        for i = 1:SearchAgents_no
            r1 = rand();
            r2 = rand();
      

            A1 = 2 * a * r1 - a;
            C1 = 2 * r2;
            D_alpha = abs(C1 * params.Alpha_pos - params.Positions(i));
            X1 = params.Alpha_pos - A1 * D_alpha;

            A2 = 2 * a * r1 - a;
            C2 = 2 * r2;
            D_beta = abs(C2 * params.Beta_pos - params.Positions(i));
            X2 = params.Beta_pos - A2 * D_beta;

            A3 = 2 * a * r1 - a;
            C3 = 2 * r2;
            D_delta = abs(C3 * params.Delta_pos - params.Positions(i));
            X3 = params.Delta_pos - A3 * D_delta;

            newPosition = (X1 + X2 + X3) / 3;

            if newPosition > ub
                newPosition = ub;
            elseif newPosition < lb
                newPosition = lb;
            end

            params.Positions(i) = newPosition;
        end

        if params.iter >= Max_iteration
            params.running = false;
            D = params.Alpha_pos;
        end
    end

    if Enabled == 0
        D = Dinit;
    end
end

function params = initialize(SearchAgents_no, lb, ub)
    params.Positions = rand(SearchAgents_no, 1) .* (ub - lb) + lb;
    params.fitness = zeros(1, SearchAgents_no);
    params.Alpha_pos = 0;
    params.Alpha_score = 0;
    params.Beta_pos = 0;
    params.Beta_score = 0;
    params.Delta_pos = 0;
    params.Delta_score = 0;
    params.iter = 0;
    params.index = 1;
    params.running = true;
    params.power_last = 0;
end